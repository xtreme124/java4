package mypack;

public class CheckerBean {
    
    String name, age, hob, gen, email, error;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getHob() {
        return hob;
    }

    public void setHob(String hob) {
        this.hob = hob;
    }

    public String getGen() {
        return gen;
    }

    public void setGen(String gen) {
        this.gen = gen;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
    
    public boolean validate() {
        boolean res = true;
        if (name.trim().equals("") || (name == null)) {
            {
                error += "<br>Enter First name";
                res = false;
            }
        }

        if (age.length() > 2 || (age == null)) {
            {
                error += "<br>Inavlid Age";
                res = false;
            }
        }
        return res;
    }   
}
